class InteractiveUI {
    constructor() {
        this.initLenis();
        this.initSpotlights();
        this.initMagnetic();
        this.initModal();
        this.initReveal();
        this.initMobileMenu();
        this.initUptime();
    }

    initLenis() {
        if(typeof Lenis === 'undefined') return;
        this.lenis = new Lenis({
            duration: 0.9,
            easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
            direction: 'vertical',
            smooth: true,
        });
        const raf = (time) => {
            this.lenis.raf(time);
            requestAnimationFrame(raf);
        };
        requestAnimationFrame(raf);
    }

    initSpotlights() {
        document.querySelectorAll('[data-spotlight]').forEach((el) => {
            el.addEventListener('mouseenter', () => { el._cachedRect = el.getBoundingClientRect(); });
            el.addEventListener('mousemove', (e) => {
                const rect = el._cachedRect || el.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                el.style.setProperty('--mouse-x', x + 'px');
                el.style.setProperty('--mouse-y', y + 'px');
            });
        });
    }

    initMagnetic() {
        const isReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (isReducedMotion || window.innerWidth < 768) return;

        document.querySelectorAll('[data-magnetic]').forEach((el) => {
            el.addEventListener('mouseenter', () => {
                el.style.transition = 'none';
                el._cachedRect = el.getBoundingClientRect();
            });
            el.addEventListener('mousemove', (e) => {
                const rect = el._cachedRect || el.getBoundingClientRect();
                const hx = rect.left + rect.width / 2;
                const hy = rect.top + rect.height / 2;
                const dx = (e.clientX - hx) * 0.15;
                const dy = (e.clientY - hy) * 0.15;
                el.style.transform = "translate(" + dx + "px, " + dy + "px) perspective(1000px) rotateX(" + (-dy * 0.5) + "deg) rotateY(" + (dx * 0.5) + "deg) scale3d(1.02, 1.02, 1.02)";
            });
            el.addEventListener('mouseleave', () => {
                el.style.transition = 'transform 0.4s cubic-bezier(0.25, 1, 0.5, 1), box-shadow 0.3s';
                el.style.transform = '';
            });
        });
    }

    initModal() {
        const modal = document.getElementById('projectModal');
        const closeBtn = document.getElementById('modalClose');
        window.openProjectModal = (title, desc, fullDesc, techs, link) => {
            document.getElementById('modalTitle').innerText = title;
            document.getElementById('modalDesc').innerText = desc;
            document.getElementById('modalFullDesc').innerText = fullDesc;
            document.getElementById('modalLink').href = link;
            const techList = document.getElementById('modalTechs');
            if(techList) {
                techList.innerHTML = '';
                techs.forEach(t => {
                    const li = document.createElement('li');
                    li.innerText = t;
                    techList.appendChild(li);
                });
            }
            if(modal) modal.classList.add('active');
            if(this.lenis) this.lenis.stop();
        };

        if(closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.classList.remove('active');
                if(this.lenis) this.lenis.start();
            });
        }
        if(modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('active');
                    if(this.lenis) this.lenis.start();
                }
            });
        }
    }

    initReveal() {
        if(typeof IntersectionObserver === 'undefined') return;
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1, rootMargin: "0px 0px -50px 0px" });
        document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    }

    initMobileMenu() {
        const menuBtn = document.querySelector('.mobile-menu-btn');
        const navLinks = document.querySelector('.nav-links');
        if(!menuBtn || !navLinks) return;

        menuBtn.addEventListener('click', () => {
            menuBtn.classList.toggle('active');
            navLinks.classList.toggle('active');
        });

        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                menuBtn.classList.remove('active');
                navLinks.classList.remove('active');
            });
        });
    }

    initUptime() {
        const uptimeEl = document.getElementById('uptime');
        if(uptimeEl) {
            let seconds = 0;
            setInterval(() => {
                seconds++;
                const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
                const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
                const s = (seconds % 60).toString().padStart(2, '0');
                uptimeEl.innerText = h + ":" + m + ":" + s;
            }, 1000);
        }
    }
}

class WebGLScene {
    constructor() {
        this.container = document.getElementById('canvas-container');
        if (!this.container || typeof THREE === 'undefined') return;

        this.isMobile = window.innerWidth < 768;
        this.isReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        // Single source of truth for cursor position — no double-smoothing.
        // targetMouse is set instantly on mousemove; mouse chases it once per frame.
        this.mouse = new THREE.Vector2(0, 0);
        this.targetMouse = new THREE.Vector2(0, 0);
        this.scrollOffset = 0;
        this.targetScrollOffset = 0;

        this.initScene();
        if (!this.isReducedMotion) {
            this.initParticles();
            this.initNeuralCluster();
        }
        this.initPostProcessing();
        this.addEvents();
        this.animate();
    }

    initScene() {
        this.scene = new THREE.Scene();
        this.scene.fog = new THREE.FogExp2(0x050508, 0.0011);

        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 2000);
        this.camera.position.z = 800;

        this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: false, powerPreference: "high-performance" });
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.25));
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.container.appendChild(this.renderer.domElement);
    }

    // Ambient background field — atmosphere only, kept subtle so it never competes
    // with the focal neural cluster or the text.
    initParticles() {
        const count = this.isMobile ? 90 : 260;
        const geometry = new THREE.BufferGeometry();
        const positions = new Float32Array(count * 3);
        const randoms = new Float32Array(count);

        for (let i = 0; i < count; i++) {
            positions[i * 3] = (Math.random() - 0.5) * 2200;
            positions[i * 3 + 1] = (Math.random() - 0.5) * 2200;
            positions[i * 3 + 2] = (Math.random() - 0.5) * 1200;
            randoms[i] = Math.random();
        }

        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('aRandom', new THREE.BufferAttribute(randoms, 1));

        this.particleMaterial = new THREE.ShaderMaterial({
            uniforms: {
                uTime: { value: 0 },
                uMouse: { value: new THREE.Vector3(0, 0, 0) },
                uColor: { value: new THREE.Color('#00D2B4') }
            },
            vertexShader: `
                uniform float uTime;
                uniform vec3 uMouse;
                attribute float aRandom;
                varying float vAlpha;

                void main() {
                    vec3 pos = position;
                    pos.y += sin(uTime * 0.4 + aRandom * 10.0) * 16.0;
                    pos.x += cos(uTime * 0.25 + aRandom * 10.0) * 16.0;

                    float dist = distance(pos.xy, uMouse.xy);
                    if(dist < 220.0) {
                        vec2 dir = normalize(pos.xy - uMouse.xy);
                        pos.xy += dir * (220.0 - dist) * 0.12;
                    }

                    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
                    gl_Position = projectionMatrix * mvPosition;
                    gl_PointSize = (10.0 * aRandom) * (1000.0 / -mvPosition.z);
                    vAlpha = aRandom * 0.35 + 0.05;
                }
            `,
            fragmentShader: `
                uniform vec3 uColor;
                varying float vAlpha;
                void main() {
                    float d = distance(gl_PointCoord, vec2(0.5));
                    if(d > 0.5) discard;
                    gl_FragColor = vec4(uColor, vAlpha * (0.5 - d));
                }
            `,
            transparent: true,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        this.particles = new THREE.Points(geometry, this.particleMaterial);
        this.scene.add(this.particles);
    }

    // The focal 3D element: a small cluster of "neurons" connected by edges —
    // a visual that actually means something for an AI/ML profile, instead of
    // a generic spinning wireframe shape. Reacts to the cursor directly
    // (position offsets, not a laggy chase), so it feels immediate.
    initNeuralCluster() {
        const group = new THREE.Group();
        const nodeCount = this.isMobile ? 22 : 34;
        const radius = 170;
        const nodePositions = [];

        for (let i = 0; i < nodeCount; i++) {
            // Fibonacci sphere distribution — even spacing, no random clumping.
            const y = 1 - (i / (nodeCount - 1)) * 2;
            const r = Math.sqrt(1 - y * y);
            const theta = Math.PI * (1 + Math.sqrt(5)) * i;
            const x = Math.cos(theta) * r;
            const z = Math.sin(theta) * r;
            nodePositions.push(new THREE.Vector3(x * radius, y * radius, z * radius));
        }

        // Nodes
        const nodeGeo = new THREE.BufferGeometry();
        const flatPositions = new Float32Array(nodeCount * 3);
        nodePositions.forEach((p, i) => {
            flatPositions[i * 3] = p.x;
            flatPositions[i * 3 + 1] = p.y;
            flatPositions[i * 3 + 2] = p.z;
        });
        nodeGeo.setAttribute('position', new THREE.BufferAttribute(flatPositions, 3));
        const nodeMat = new THREE.PointsMaterial({
            color: 0x00D2B4,
            size: 5.5,
            transparent: true,
            opacity: 0.85,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            sizeAttenuation: true
        });
        const nodes = new THREE.Points(nodeGeo, nodeMat);
        group.add(nodes);

        // Edges — connect each node to its nearest few neighbors only,
        // so it reads as a network, not a solid ball.
        const edgeVerts = [];
        const maxNeighborDist = radius * 0.85;
        for (let i = 0; i < nodePositions.length; i++) {
            let neighbors = [];
            for (let j = 0; j < nodePositions.length; j++) {
                if (i === j) continue;
                const d = nodePositions[i].distanceTo(nodePositions[j]);
                if (d < maxNeighborDist) neighbors.push({ j, d });
            }
            neighbors.sort((a, b) => a.d - b.d);
            neighbors.slice(0, 2).forEach(n => {
                edgeVerts.push(nodePositions[i].x, nodePositions[i].y, nodePositions[i].z);
                edgeVerts.push(nodePositions[n.j].x, nodePositions[n.j].y, nodePositions[n.j].z);
            });
        }
        const edgeGeo = new THREE.BufferGeometry();
        edgeGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(edgeVerts), 3));
        const edgeMat = new THREE.LineBasicMaterial({
            color: 0x00D2B4,
            transparent: true,
            opacity: 0.18,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });
        const edges = new THREE.LineSegments(edgeGeo, edgeMat);
        group.add(edges);

        group.position.set(window.innerWidth > 992 ? 380 : 0, 60, -100);
        this.scene.add(group);
        this.neuralCluster = group;
    }

    initPostProcessing() {
        if(typeof THREE.EffectComposer !== 'undefined') {
            this.composer = new THREE.EffectComposer(this.renderer);
            this.composer.addPass(new THREE.RenderPass(this.scene, this.camera));

            if (!this.isMobile && !this.isReducedMotion) {
                // Lower strength than before — bloom should add a soft glow,
                // not wash the whole scene out.
                const bloomPass = new THREE.UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 0.7, 0.6, 0.25);
                this.composer.addPass(bloomPass);
            }
        }
    }

    addEvents() {
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
            if(this.composer) this.composer.setSize(window.innerWidth, window.innerHeight);
            this.isMobile = window.innerWidth < 768;
            if (this.neuralCluster) {
                this.neuralCluster.position.x = window.innerWidth > 992 ? 380 : 0;
            }
        });

        window.addEventListener('mousemove', (e) => {
            this.targetMouse.x = (e.clientX - window.innerWidth / 2);
            this.targetMouse.y = -(e.clientY - window.innerHeight / 2);
        });

        // Recenter smoothly instead of leaving the scene frozen at the last
        // cursor position when the pointer leaves the window.
        window.addEventListener('mouseleave', () => {
            this.targetMouse.x = 0;
            this.targetMouse.y = 0;
        });

        window.addEventListener('scroll', () => {
            this.targetScrollOffset = window.scrollY;
        }, { passive: true });
    }

    animate() {
        requestAnimationFrame(this.animate.bind(this));

        // ONE smoothing pass, tuned to settle in a couple of frames rather
        // than drifting for a second after the cursor stops.
        this.mouse.x += (this.targetMouse.x - this.mouse.x) * 0.18;
        this.mouse.y += (this.targetMouse.y - this.mouse.y) * 0.18;
        this.scrollOffset += (this.targetScrollOffset - this.scrollOffset) * 0.12;

        if (this.particleMaterial) {
            this.particleMaterial.uniforms.uTime.value += 0.01;
            this.particleMaterial.uniforms.uMouse.value.set(this.mouse.x, this.mouse.y + this.scrollOffset, 0);
        }

        if (this.neuralCluster) {
            this.neuralCluster.rotation.y += 0.0015;
            this.neuralCluster.rotation.x = this.mouse.y * 0.00025;
            // Direct offset from the already-smoothed mouse value — no second
            // lerp layer, so the cluster's tilt matches the cursor immediately.
            this.neuralCluster.rotation.z = -this.mouse.x * 0.00015;
            this.neuralCluster.position.y = 60 - this.scrollOffset * 0.35;
        }

        if (!this.isReducedMotion) {
            const targetCamX = this.mouse.x * 0.04;
            const targetCamY = -(this.scrollOffset * 0.4) + this.mouse.y * 0.04;
            this.camera.position.x += (targetCamX - this.camera.position.x) * 0.15;
            this.camera.position.y += (targetCamY - this.camera.position.y) * 0.15;
        }

        if(this.composer) {
            this.composer.render();
        } else {
            this.renderer.render(this.scene, this.camera);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new InteractiveUI();
    new WebGLScene();
});






